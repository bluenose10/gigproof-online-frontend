// Production base URL
const BASE_URL = 'https://gigproof.online';
