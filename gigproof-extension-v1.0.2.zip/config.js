// Base URL - Production URL for gigproof.online
// IMPORTANT: Only change to localhost for local development testing
// For GitHub/Production: MUST be https://gigproof.online
const BASE_URL = 'https://gigproof.online';
